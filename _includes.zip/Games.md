---
layout: page
title: Games
permalink: /games/
---
# My Public Games

- [MOON MISS SHOT](https://moggrat.itch.io/moon-miss-shot)
This was my entry into the GitHub Game Off 2020 game jam. The theme was MOONSHOT. This theme alongside other inspirations resulted in me developing a gravity system and the game around this system.
- [Hazardman](https://moggrat.itch.io/hazardman)
This was my entry into the ANYTHING GOES JAM (game jam). I joined the jam late, but I was able to create a rough prototype in those two days.

# Other Games I've worked on

- Final Year Project. Using Unity and Socket.io I created a 6+ player multiplayer game. Players controller their "duck" using a webpage on their smartphones.
- Second Year Group Project. Using an old Java API we created a 3 level shoot 'em up space game. This game supported 2 players (on one keyboard).
- College Project. I created a simple rogue-like prototype using monogame.

# [See other stuff I've created](../projects)
