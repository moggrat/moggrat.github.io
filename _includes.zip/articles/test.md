---
# Feel free to add content and custom Front Matter to this file.
# To modify the layout, see https://jekyllrb.com/docs/themes/#overriding-theme-defaults

layout: page
permalink: /article/test
title: " "
---
## Hello this is a testpage

### :)

This is a sample page I will use for future non blog related posts.

I should use a variable and a check in the nav.html but this is a simpler solution to maintain (I also dont know if I will use this yet).

Good job of finding this page.

-Luke 😘
