---
# Feel free to add content and custom Front Matter to this file.
# To modify the layout, see https://jekyllrb.com/docs/themes/#overriding-theme-defaults

layout: home

---
**Hello 👋**

I’m Luke Scott a computer science graduate from NW England, and I build all sorts of programs, websites and video games. [Read More](/about)

{% include twitterfollow.html %}



**Recent Project/Game:**

[![Gamejam Game Entry](/assets/moonmissshot.png)](https://moggrat.itch.io/moon-miss-shot)
